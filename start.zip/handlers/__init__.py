from .user import start
from .admin import awaited_messages, menu, spam_all, stats, timer, manage_messages