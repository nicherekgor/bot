from aiogram import types
from aiogram.dispatcher import FSMContext

from utils.misc import dp, config
from utils import database


@dp.message_handler(text = '/admin', state = '*')
async def admin_menu(msg: types.Message, state: FSMContext):
    try: await state.finish()
    except: pass

    if not str(msg.from_user.id) in config['MAIN']['ADMINS'].split(':'):
        return
    
    if msg.chat.type != 'private':
        return
        
    await msg.delete()

    settings = await database.get_settings()

    await msg.answer('<b>Меню администратора</b> \n'
                     f'<b>Таймер принятия:</b> {settings[0]} минут',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Рассылка по всем',
                                                    callback_data = 'spam_all')
                     ).add(
                         types.InlineKeyboardButton('Отложенные сообщения',
                                                    callback_data = 'awaited_messages')
                     ).add(
                         types.InlineKeyboardButton('Изменить таймер принятия',
                                                    callback_data = 'change_accepting_timer')
                     ).add(
                         types.InlineKeyboardButton('Статистика',
                                                    callback_data = 'statistics')
                     ).add(
                         types.InlineKeyboardButton('Управление сообщениями',
                                                    callback_data = 'manage_messages')
                     ))



@dp.callback_query_handler(text = 'admin', state = '*')
async def admin_menu(call: types.CallbackQuery, state: FSMContext):
    try: await state.finish()
    except: pass

    if not str(call.from_user.id) in config['MAIN']['ADMINS'].split(':'):
        return
    
    settings = await database.get_settings()

    await call.message.answer('<b>Меню администратора</b> \n'
                              f'<b>Таймер принятия:</b> {settings[0]} минут',
                              reply_markup=types.InlineKeyboardMarkup().add(
                                  types.InlineKeyboardButton('Рассылка по всем',
                                                             callback_data = 'spam_all')
                              ).add(
                                  types.InlineKeyboardButton('Отложенные сообщения',
                                                             callback_data = 'awaited_messages')
                              ).add(
                                  types.InlineKeyboardButton('Изменить таймер принятия',
                                                             callback_data = 'change_accepting_timer')
                              ).add(
                                  types.InlineKeyboardButton('Статистика',
                                                             callback_data = 'statistics')
                              ).add(
                                  types.InlineKeyboardButton('Управление сообщениями',
                                                             callback_data = 'manage_messages')
                              ))
