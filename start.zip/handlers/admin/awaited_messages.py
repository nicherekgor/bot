from aiogram import types
from aiogram.dispatcher import FSMContext

from utils.misc import dp, bot
from utils import states, database

import asyncio, json


@dp.callback_query_handler(text = 'awaited_messages', state = '*')
async def awaited_messagesMenu(call: types.CallbackQuery, state: FSMContext):
    try: await state.finish()
    except: pass

    await call.message.answer('<b>Введите интервал между сообщениями: (в минутах)</b>',
                         reply_markup=types.InlineKeyboardMarkup().add(
                             types.InlineKeyboardButton('Отмена',
                                                        callback_data='admin')
                         ))
    
    await states.create_waiten_msg.q2.set()



@dp.message_handler(state = states.create_waiten_msg.q2)
async def set_interval(msg: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['interval'] = msg.text

    await msg.answer('<b>Введите сообщение для добавления:</b> \n\n'
                     '<b>По желанию можно добавить фото</b> \n'
                     '<b>Чтобы добавить кнопки используйте шаблон ниже:</b> \n\n'
                     '<code>кнопки: \n'
                     'название кнопки*ссылка \n'
                     'название кнопки*ссылка</code> \n\n'
                     '<i>Слово "кнопки" обязательно</i>',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Отмена',
                                                    callback_data='admin')
                     ))
    
    await states.create_waiten_msg.q3.set()
    async with state.proxy() as data:
        data['text'] = []
        data['pic'] = []



@dp.message_handler(state = states.create_waiten_msg.q3, content_types=types.ContentTypes.ANY)
async def messages_creating(msg: types.Message, state: FSMContext):
    async with state.proxy() as data:
        texts: list = data['text']
        pics: list = data['pic']

        if msg.photo:
            pics.append(msg.photo[-1].file_id)

        else:
            pics.append(None)

        if msg.caption:
            texts.append(msg.caption)

        else:
            texts.append(msg.text)

        data['text'] = texts
        data['pics'] = pics

    await msg.answer('<b>Сообщение добавлено</b> \n'
                     '<b>Вы можете отправить ещё</b>',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Завершить цепочку',
                                                    callback_data='chain_done')
                     ).add(
                         types.InlineKeyboardButton('Отмена',
                                                    callback_data='admin')
                     ))
    


@dp.callback_query_handler(text = 'chain_done', state = '*')
async def chain_created(call: types.CallbackQuery, state: FSMContext):
    async with state.proxy() as data:
        texts: list = data['text']
        pics: list = data['pic']
        interval: int = int(data['interval']) * 60

    await call.message.edit_text('<b>Цепочка завершена, сообщения созданы</b>',
                                 reply_markup=types.InlineKeyboardMarkup().add(
                                     types.InlineKeyboardButton('Назад',
                                                                callback_data='admin')
                                 ))
    
    await database.add_queueInterval(interval)
    await database.add_queueText(json.dumps(texts))
    await database.add_queuePics(json.dumps(pics))
