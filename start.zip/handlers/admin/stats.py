from aiogram import types

from utils.misc import dp
from utils import database

import datetime


@dp.callback_query_handler(text = 'statistics')
async def stats_showChoise(call: types.CallbackQuery):
    await call.message.edit_text('<b>Выберите период статистики:</b>',
                                 reply_markup=types.InlineKeyboardMarkup().add(
                                     types.InlineKeyboardButton('Сегодня',
                                                                callback_data='show_stat:1')
                                 ).add(
                                     types.InlineKeyboardButton('Неделя',
                                                                callback_data='show_stat:2')
                                 ).add(
                                     types.InlineKeyboardButton('Месяц',
                                                                callback_data='show_stat:3')
                                 ).add(
                                     types.InlineKeyboardButton('Назад',
                                                                callback_data='admin')
                                 ))



@dp.callback_query_handler(text_startswith = 'show_stat')
async def stats_showen(call: types.CallbackQuery):
    choice = call.data.split(':')[1]

    if int(choice) == 1:
        accepts = await database.get_accepts(datetime.date.today(), datetime.date.today())
        leaves = await database.get_leaves(datetime.date.today(), datetime.date.today())

    elif int(choice) == 2:
        accepts = await database.get_accepts(datetime.date.today() - datetime.timedelta(days=7), datetime.date.today())
        leaves = await database.get_leaves(datetime.date.today() - datetime.timedelta(days=7), datetime.date.today())

    else:
        accepts = await database.get_accepts(datetime.date.today() - datetime.timedelta(days=30), datetime.date.today())
        leaves = await database.get_leaves(datetime.date.today() - datetime.timedelta(days=30), datetime.date.today())

    await call.message.edit_text('<b>Вот ваша статистика:</b> \n\n'
                                 f'Подали заявку на вступление в канал: {len(accepts)} \n'
                                 f'Принято в канал: {len(accepts)} \n'
                                 f'Покинуло канал: {len(leaves)} \n'
                                 f'Заблокировали бота: {len(leaves)} ',
                                 reply_markup=types.InlineKeyboardMarkup().add(
                                     types.InlineKeyboardButton('Назад',
                                                                callback_data='statistics')
                                 ))
