from aiogram import types
from aiogram.dispatcher import FSMContext

from utils.misc import dp, config, bot
from utils import database, states


@dp.callback_query_handler(text = 'manage_messages')
async def message_managing(call: types.CallbackQuery):
    await call.message.edit_text('<b>Выберите опцию:</b>',
                                 reply_markup = types.InlineKeyboardMarkup().add(
                                     types.InlineKeyboardButton('Изменить приветственное сообщение',
                                                                callback_data = 'change_message:1')
                                 ).add(
                                     types.InlineKeyboardButton('Изменить прощальное сообщение',
                                                                callback_data = 'change_message:2')
                                 ))



@dp.callback_query_handler(text_startswith = 'change_message')
async def changing_message(call: types.CallbackQuery):
    settings = await database.get_settings()

    if int(call.data.split(':')[1]) == 1:
        if settings[2] is not None:
            kb = types.InlineKeyboardMarkup()

            for i in str(settings[2]).split('\n'):
                if len(i.split('*')) == 2:
                    kb.add(
                        types.InlineKeyboardButton(f'{i.split("*")[0]}',
                                                url = f'{i.split("*")[1]}')
                    )

        else:
            kb = None

        if settings[3] is None:
            if kb is None:
                await bot.send_message(call.from_user.id,
                                    settings[1])
                
            else:
                await bot.send_message(call.from_user.id,
                                    settings[1],
                                    reply_markup=kb)
        
        if settings[3] is not None:
            if kb is None:
                await bot.send_photo(call.from_user.id,
                                    settings[3],
                                    settings[1])
                
            else:
                await bot.send_photo(call.from_user.id,
                                    settings[3],
                                    settings[1],
                                    reply_markup=kb)
                
        await call.message.answer('<b>Выберите действие с этим сообщением:</b>',
                                  reply_markup=types.InlineKeyboardMarkup().add(
                                      types.InlineKeyboardButton('Изменить',
                                                                 callback_data='change_approved:1')
                                  ).add(
                                      types.InlineKeyboardButton('Назад',
                                                                 callback_data='admin')
                                  ))

    else:
        if settings[5] is not None:
            kb = types.InlineKeyboardMarkup()
            for i in str(settings[5]).split('\n'):
                if len(i.split('*')) == 2:
                    kb.add(
                        types.InlineKeyboardButton(f'{i.split("*")[0]}',
                                                url = f'{i.split("*")[1]}')
                    )

        else:
            kb = None

        if settings[6] is None:
            if kb is None:
                await bot.send_message(call.from_user.id,
                                    settings[4])
                
            else:
                await bot.send_message(call.from_user.id,
                                    settings[4],
                                    reply_markup=kb)
        
        if settings[6] is not None:
            if kb is None:
                await bot.send_photo(call.from_user.id,
                                    settings[6],
                                    settings[4])
                
            else:
                await bot.send_photo(call.from_user.id,
                                    settings[6],
                                    settings[4],
                                    reply_markup=kb)

        await call.message.answer('<b>Выберите действие с этим сообщением:</b>',
                                  reply_markup=types.InlineKeyboardMarkup().add(
                                      types.InlineKeyboardButton('Изменить',
                                                                 callback_data='change_approved:2')
                                  ).add(
                                      types.InlineKeyboardButton('Назад',
                                                                 callback_data='admin')
                                  ))
        


@dp.callback_query_handler(text_startswith = 'change_approved')
async def change_firstStep(call: types.CallbackQuery, state: FSMContext):
    chosen_message = call.data.split(':')[1]

    await call.message.edit_text('<b>Введите текст сообщения:</b>',
                                 reply_markup=types.InlineKeyboardMarkup().add(
                                     types.InlineKeyboardButton('Отмена',
                                                                callback_data='admin')
                                 ))
    
    await states.message_edition.q1.set()
    async with state.proxy() as data:
        data['message'] = chosen_message



@dp.message_handler(state = states.message_edition.q1)
async def change_secondStep(msg: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['text'] = msg.text

    await msg.delete()
    await msg.answer('<b>Отправьте кнопки для добавления:</b> \n\n'
                     '<b>Пример отправки: (название:ссылка)</b> \n'
                     '<b>Чтобы отправить несколько кнопок отправляйте их с переносом строки</b> \n\n'
                     '<b>Например:</b> \n'
                     '<code>Название кнопки*https://t.me/username</code> \n'
                     '<code>Название кнопки*https://t.me/username</code> \n\n'
                     '<b>Если вы не хотите добавлять кнопки введите 0</b>',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Отмена',
                                                    callback_data='admin')
                     ))

    await states.message_edition.q2.set()



@dp.message_handler(state = states.message_edition.q2)
async def change_thirdStep(msg: types.Message, state: FSMContext):
    async with state.proxy() as data:
        if msg.text == '0':
            data['buttons'] = None

        else:
            data['buttons'] = msg.text

    await msg.delete()
    await msg.answer('<b>Отправьте фото, или если хотите оставить без него, то введите 0</b>',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Отмена',
                                                    callback_data='admin')
                     ))
    
    await states.message_edition.q3.set()



@dp.message_handler(state = states.message_edition.q3, content_types = types.ContentTypes.ANY)
async def change_done(msg: types.Message, state: FSMContext):
    async with state.proxy() as data:
        message_choice = data['message']
        text = data['text']
        buttons = data['buttons']

    if int(message_choice) == 1:
        if msg.photo:
            await database.change_hi_message(text,
                                            buttons,
                                            msg.photo[-1].file_id)

        else:
            await database.change_hi_message(text,
                                            buttons,
                                            None)
        
    else:
        if msg.photo:
            await database.change_gb_message(text,
                                            buttons,
                                            msg.photo[-1].file_id)
            
        else:
            await database.change_gb_message(text,
                                            buttons,
                                            None)
    
    await msg.delete()
    await msg.answer('<b>Сообщение изменено</b>',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Назад',
                                                    callback_data='admin')
                     ))
