from aiogram import types
from aiogram.dispatcher import FSMContext

from utils.misc import dp, bot
from utils import database, states

import asyncio


@dp.callback_query_handler(text = 'spam_all', state = '*')
async def spam_menu(call: types.CallbackQuery, state: FSMContext):
    try: await state.finish()
    except: pass

    kb = types.InlineKeyboardMarkup()

    kb.add(
        types.InlineKeyboardButton('Всем пользователям',
                                   callback_data='send_spam:0')
    )

    await call.message.edit_text('<b>Выберите кому будем отправлять рассылку: </b>',
                                 reply_markup=kb)
    


@dp.callback_query_handler(text_startswith = 'send_spam')
async def spam_waiting(call: types.CallbackQuery):
    if int(call.data.split(':')[1]) == 0:
        await call.message.edit_text('<b>Отправьте сообщение для рассылки:</b>',
                                    reply_markup=types.InlineKeyboardMarkup().add(
                                        types.InlineKeyboardButton('Назад',
                                                                    callback_data='admin')
                                    ))
        
        await states.spam.q1.set()

    else:
        await call.message.edit_text('<b>Этот функционал для рассылки по группам пользователей ещё не написан</b>')



@dp.message_handler(state = states.spam.q1)
async def spamming_process(msg: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['text'] = msg.text

    await msg.delete()
    await msg.answer('<b>Введите кнопки в формате ниже, если хотите оставить без них, введите 0:</b> \n\n'
                     '<code>название кнопки*ссылка \n'
                     'название кнпоки*ссылка</code>',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Назад',
                                                    callback_data='admin')
                     ))
    
    await states.spam.q2.set()



@dp.message_handler(state = states.spam.q2)
async def spamming_stageTwo(msg: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['buttons'] = msg.text

    await msg.delete()
    await msg.answer('<b>Отправьте фото, если хотите оставить без него, то введите 0:</b>',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Назад',
                                                    callback_data='admin')
                     ))
    
    await states.spam.q3.set()



@dp.message_handler(state = states.spam.q3, content_types=types.ContentTypes.ANY)
async def spamming_stageCheck(msg: types.Message, state: FSMContext):
    async with state.proxy() as data:
        if msg.text == '0':
            data['pic'] = None

        else:
            data['pic'] = msg.photo[-1].file_id

        buttons = data['buttons']
        text = data['text']

    await msg.delete()

    if buttons != '0':
        kb = types.InlineKeyboardMarkup()

        for i in str(buttons).split('\n'):
            kb.add(
                types.InlineKeyboardButton(f'{i.split("*")[0]}',
                                           url = i.split('*')[1])
            )

    else:
        kb = None

    if msg.photo:
        if kb is not None:
            await bot.send_photo(msg.from_user.id,
                                msg.photo[-1].file_id,
                                text,
                                reply_markup=kb)
            
        else:
            await bot.send_photo(msg.from_user.id,
                                msg.photo[-1].file_id,
                                text)
        
    else:
        if kb is not None:
            await bot.send_message(msg.from_user.id,
                                text,
                                reply_markup=kb)
            
        else:
            await bot.send_message(msg.from_user.id,
                                text)

    await msg.answer('<b>Отправляем рассылку?</b>',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Да',
                                                    callback_data='confirm_spam')
                     ).add(
                         types.InlineKeyboardButton('Нет',
                                                    callback_data='admin')
                     ))



@dp.callback_query_handler(text = 'confirm_spam', state = '*')
async def spamming_finish(call: types.CallbackQuery, state: FSMContext):
    async with state.proxy() as data:
        pic = data['pic']
        buttons = data['buttons']
        text = data['text']

    await call.message.edit_text('<b>Рассылка началась</b>')

    if buttons != '0':
        kb = types.InlineKeyboardMarkup()

        for i in str(buttons).split('\n'):
            kb.add(
                types.InlineKeyboardButton(f'{i.split("*")[0]}',
                                           url = i.split('*')[1])
            )

    else:
        kb = None

    users = await database.get_users()

    for i in users:
        if pic is not None:
            if kb is not None:
                try:

                    await bot.send_photo(i[0],
                                        pic,
                                        text,
                                        reply_markup=kb)
                except:
                    pass
                
            else:
                try:
                    await bot.send_photo(i[0],
                                        pic,
                                        text)
                
                except:
                    pass
            
        else:
            if kb is not None:
                try:
                    await bot.send_message(i[0],
                                        text,
                                        reply_markup=kb)
                
                except:
                    pass
                
            else:
                try:
                    await bot.send_message(i[0],
                                        text)
                
                except:
                    pass
                
        await asyncio.sleep(0.33)

    await call.message.answer('<b>Рассылка завершена</b>',
                              reply_markup=types.InlineKeyboardMarkup().add(
                                  types.InlineKeyboardButton('Назад',
                                                             callback_data='admin')
                              ))