from aiogram import types
from aiogram.dispatcher import FSMContext

from utils.misc import dp
from utils import database, states


@dp.callback_query_handler(text = 'change_accepting_timer')
async def change_timer(call: types.CallbackQuery):
    settings = await database.get_settings()

    await call.message.edit_text('<b>Введите новый период работы таймера:</b> \n'
                                 f'<b>Таймер сейчас:</b> {settings[0]} минут',
                                 reply_markup=types.InlineKeyboardMarkup().add(
                                     types.InlineKeyboardButton('Назад',
                                                                callback_data='admin')
                                 ))
    
    await states.timer_changing.q1.set()



@dp.message_handler(state = states.timer_changing.q1)
async def timer_changed(msg: types.Message, state: FSMContext):
    await state.finish()
    
    await database.change_timeout(msg.text)

    await msg.answer('<b>Таймер изменён</b>',
                     reply_markup=types.InlineKeyboardMarkup().add(
                         types.InlineKeyboardButton('Назад',
                                                    callback_data='admin')
                     ))    
