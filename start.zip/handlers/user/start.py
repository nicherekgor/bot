from aiogram import types

from utils.misc import dp, config, bot
from utils import database

import datetime, asyncio, json


@dp.chat_join_request_handler(chat_id = config['MAIN']['INVITE_CHAT'])
async def chat_join(request: types.ChatJoinRequest):
    settings = await database.get_settings()

    await asyncio.sleep(int(settings[0]) * 60)

    await request.approve()

    settings = await database.get_settings()

    if settings[2] is not None:
        kb = types.InlineKeyboardMarkup()
        
        for i in str(settings[2]).split('\n'):
            kb.add(
                types.InlineKeyboardButton(f'{i.split("*")[0]}',
                                           url = f'{i.split("*")[1]}')
            )

    else:
        kb = None

    if settings[3] is None:
        if kb is None:
            await bot.send_message(request.from_user.id,
                                settings[1])
            
        else:
            await bot.send_message(request.from_user.id,
                                settings[1],
                                reply_markup=kb)
    
    else:
        if kb is None:
            await bot.send_photo(request.from_user.id,
                                settings[3],
                                settings[1])
            
        else:
            await bot.send_photo(request.from_user.id,
                                settings[3],
                                settings[1],
                                reply_markup=kb)
    
    await database.add_user(request.from_user.id,
                            request.from_user.username)
    
    await database.add_accept(request.from_user.id,
                              datetime.date.today())
    
    await chain_turn(request.from_user.id)



async def chain_turn(user_id):
    counter = 0

    queue = await database.get_queue()

    await asyncio.sleep(queue[0])

    for i in json.loads(queue[1]):
        if 'кнопки:' in str(i).lower():
            buttons_unformatted = str(i).split('кнопки:')[1]

            kb = types.InlineKeyboardMarkup()

            for j in buttons_unformatted.split('\n'):
                if len(j.split('*')) == 2:
                    kb.add(
                        types.InlineKeyboardButton(f'{j.split("*")[0]}',
                                                url=f'{j.split("*")[1]}')
                    )

        else:
            kb = None

        if json.loads(queue[2])[counter] is None:
            if kb is not None:
                await bot.send_message(user_id,
                                    str(i).split('кнопки:')[0],
                                    reply_markup=kb)
                
            else:
                await bot.send_message(user_id,
                                    str(i).split('кнопки:')[0])

        if json.loads(queue[2])[counter] is not None or json.loads(queue[2])[counter] != 'null':
            if kb is not None:
                await bot.send_photo(user_id, 
                                    json.loads(queue[2])[counter],
                                    str(i).split('кнопки:')[0],
                                    reply_markup=kb)
                
            else:
                try:
                    await bot.send_photo(user_id, 
                                        json.loads(queue[2])[counter],
                                        str(i).split('кнопки:')[0])
                
                except:
                    pass

        counter += 1

        await asyncio.sleep(queue[0])



async def user_left(user_id: int):
    settings = await database.get_settings()

    if settings[5] is not None:
        kb = types.InlineKeyboardMarkup()

        for i in str(settings[5]).split('\n'):
            if len(i.split('*')) == 2:
                kb.add(
                    types.InlineKeyboardButton(f'{i.split("*")[0]}',
                                            url = f'{i.split("*")[1]}')
                )

    else:
        kb = None

    if settings[6] is None:
        if kb is None:
            await bot.send_message(user_id,
                                settings[4])
            
        else:
            await bot.send_message(user_id,
                                settings[4],
                                reply_markup=kb)
    
    if settings[6] is not None:
        if kb is None:
            await bot.send_photo(user_id,
                                settings[6],
                                settings[4])
            
        else:
            await bot.send_photo(user_id,
                                settings[6],
                                settings[4],
                                reply_markup=kb)

    await database.del_user(user_id)

    await database.add_leave(user_id,
                              datetime.date.today())
