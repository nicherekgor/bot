from aiogram.dispatcher.filters.state import State, StatesGroup


class spam(StatesGroup):
    q1 = State()
    q2 = State()
    q3 = State()

class timer_changing(StatesGroup):
    q1 = State()

class message_edition(StatesGroup):
    q1 = State()
    q2 = State()
    q3 = State()

class create_waiten_msg(StatesGroup):
    q1 = State()
    q2 = State()
    q3 = State()
