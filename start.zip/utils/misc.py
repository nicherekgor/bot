from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from configparser import ConfigParser
import logging

from utils import database

import asyncio, datetime


config = ConfigParser()
config.read("cfg/config.ini", encoding = "utf-8")


bot = Bot(token = config["MAIN"]["TOKEN"], parse_mode = "HTML")
dp = Dispatcher(bot, storage = MemoryStorage())


async def check_uninvites():
    users = await database.get_users()
    for i in users:
        user_channel_status = await bot.get_chat_member(chat_id=config['MAIN']['INVITE_CHAT'], user_id=i[0])
        if user_channel_status["status"] == 'left':
            settings = await database.get_settings()

            if settings[5] is not None:
                kb = types.InlineKeyboardMarkup()

                for i in str(settings[5]).split('\n'):
                    if len(i.split('*')) == 2:
                        kb.add(
                            types.InlineKeyboardButton(f'{i.split("*")[0]}',
                                                    url = f'{i.split("*")[1]}')
                        )

            else:
                kb = None

            if settings[6] is None:
                if kb is None:
                    try:
                        await bot.send_message(i[0],
                                            settings[4])
                    except:
                        pass
                    
                else:
                    try:
                        await bot.send_message(i[0],
                                            settings[4],
                                            reply_markup=kb)
                    except:
                        pass
            
            if settings[6] is not None:
                if kb is None:
                    try:
                        await bot.send_photo(i[0],
                                            settings[6],
                                            settings[4])
                    except:
                        pass
                    
                else:
                    try:
                        await bot.send_photo(i[0],
                                            settings[6],
                                            settings[4],
                                            reply_markup=kb)
                    except:
                        pass

            await database.del_user(i[0])

            await database.add_leave(i[0],
                                    datetime.date.today())

        await asyncio.sleep(0.2)


scheduler = AsyncIOScheduler()
scheduler.add_job(check_uninvites, 'interval', seconds=5)
scheduler.start()


logging.basicConfig(level = logging.INFO)