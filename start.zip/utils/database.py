import aiosqlite


async def add_user(user_id: int, username: str):
    """Adding user to users table

    Args:
        user_id (int): telegram account id
        username (str): telegram account name
    """
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('INSERT INTO users (user_id, username) VALUES (?, ?)', (user_id, username,))
        await db.commit()



async def add_queueInterval(interval: int):
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('UPDATE queue SET interval = ?', (interval,))
        await db.commit()



async def add_queueText(texts: str):
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('UPDATE queue SET texts = ?', (texts,))
        await db.commit()



async def add_queuePics(pics: str):
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('UPDATE queue SET pics = ?', (pics,))
        await db.commit()



async def add_accept(user_id: int, date: str):
    """Adding acception

    Args:
        user_id (int): telegram account id
        date (str): datetime.date
    """
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('INSERT INTO accepts (user_id, date) VALUES (?, ?)', (user_id, date,))
        await db.commit()



async def add_leave(user_id: int, date: str):
    """Adding leaving

    Args:
        user_id (int): telegram account id
        date (str): datetime.date
    """
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('INSERT INTO leaves (user_id, date) VALUES (?, ?)', (user_id, date,))
        await db.commit()



async def del_user(user_id: int):
    """Delete user from users table

    Args:
        user_id (int): telegram account id
    """
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('DELETE FROM users WHERE user_id = ?', (user_id,))
        await db.commit()



async def get_accepts(date_from: str, date_to: str):
    async with aiosqlite.connect('data/db.db') as db:
        cursor = await db.execute('SELECT * FROM accepts WHERE date BETWEEN ? AND ?', (date_from, date_to))
        result = await cursor.fetchall()
        return result



async def get_leaves(date_from: str, date_to: str):
    async with aiosqlite.connect('data/db.db') as db:
        cursor = await db.execute('SELECT * FROM leaves WHERE date BETWEEN ? AND ?', (date_from, date_to))
        result = await cursor.fetchall()
        return result



async def get_userdataUsername(username: str):
    """Get user by username

    Args:
        username (str): username without @

    Returns:
        tuple: _description_
    """
    async with aiosqlite.connect('data/db.db') as db:
        cursor = await db.execute('SELECT * FROM users WHERE username = ?', (username,))
        result = await cursor.fetchone()
        return result



async def change_gb_message(message: str, buttons: str, photo: str):
    """Change hello message

    Args:
        message (str): message
        buttons (str): buttons
        photo (str): photo
    """
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('UPDATE settings SET gb_msg = ?', (message,))
        await db.execute('UPDATE settings SET gb_msg_buttons = ?', (buttons,))
        await db.execute('UPDATE settings SET gb_msg_pic = ?', (photo,))
        await db.commit()



async def change_hi_message(message: str, buttons: str, photo: str):
    """Change hello message

    Args:
        message (str): message
        buttons (str): buttons
        photo (str): photo
    """
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('UPDATE settings SET hello_msg = ?', (message,))
        await db.execute('UPDATE settings SET hello_msg_buttons = ?', (buttons,))
        await db.execute('UPDATE settings SET hello_msg_pic = ?', (photo,))
        await db.commit()



async def change_timeout(timeout: int):
    """Change timeout in settings

    Args:
        timeout (int): minutes
    """
    async with aiosqlite.connect('data/db.db') as db:
        await db.execute('UPDATE settings SET timeout = ?', (timeout,))
        await db.commit()



async def get_users():
    """Get all users

    Returns:
        list: _description_
    """
    async with aiosqlite.connect('data/db.db') as db:
        cursor = await db.execute('SELECT * FROM users')
        result = await cursor.fetchall()
        return result



async def get_queue():
    async with aiosqlite.connect('data/db.db') as db:
        cursor = await db.execute('SELECT * FROM queue')
        result = await cursor.fetchone()
        return result



async def get_settings():
    """Get settings

    Returns:
        list: _description_
    """
    async with aiosqlite.connect('data/db.db') as db:
        cursor = await db.execute('SELECT * FROM settings')
        result = await cursor.fetchone()
        return result



async def get_userdata(user_id: int):
    """Get information about user from users table

    Args:
        user_id (int): telegram account id

    Returns:
        Tuple: information about user
    """
    async with aiosqlite.connect('data/db.db') as db:
        cursor = await db.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        result = await cursor.fetchone()
        return result



async def user_exists(user_id: int):
    """Check if user exists in table users

    Args:
        user_id (int): telegram account id

    Returns:
        Bool: True = exist, False = no
    """
    async with aiosqlite.connect('data/db.db') as db:
        cursor = await db.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        result = await cursor.fetchall()
        return bool(len(result))
